package com.somalirp.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.zip.*;

public class MainActivity extends Activity {
    // ===== EDIT THESE =====
    static final String SERVER_IP = "51.254.178.238";
    static final int SERVER_PORT = 7777;
    static final String GAME_ID = "";      // game package ID (send it to Claude)
    static final String GAME_URL = "";     // link of game zip file (host link)
    static final String DISCORD = "https://discord.com";
    static final String INSTAGRAM = "https://instagram.com";
    static final String WEBSITE = "https://example.com";
    static final String APP_LINK = "https://example.com";
    // ======================

    SharedPreferences sp;
    EditText name;
    Button action;
    ProgressBar bar;
    TextView online, players;
    LinearLayout playersCard;
    Button settings;
    MediaPlayer mp;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(r)); return g;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("srp", MODE_PRIVATE);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.logo);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View dim = new View(this);
        dim.setBackgroundColor(0xAA000000);
        root.addView(dim, new FrameLayout.LayoutParams(-1, -1));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(230), dp(230), Gravity.CENTER);
        root.addView(logo, lp);

        // top-left: account name
        name = new EditText(this);
        name.setHint("Magacaaga");
        name.setHintTextColor(0x99FFFFFF);
        name.setTextColor(Color.WHITE);
        name.setSingleLine(true);
        name.setInputType(InputType.TYPE_CLASS_TEXT);
        name.setText(sp.getString("name", ""));
        name.setBackground(round(0xAA1B1B1B, 14));
        name.setPadding(dp(16), dp(10), dp(16), dp(10));
        FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(dp(220), -2, Gravity.TOP | Gravity.START);
        nlp.setMargins(dp(16), dp(16), 0, 0);
        root.addView(name, nlp);

        // top-right: online + settings (hidden until game is ready)
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        online = new TextView(this);
        online.setTextColor(Color.WHITE);
        online.setTextSize(15);
        online.setPadding(dp(16), dp(10), dp(16), dp(10));
        online.setBackground(round(0xAA1B1B1B, 14));
        online.setVisibility(View.GONE);
        settings = new Button(this);
        settings.setText("\u2699");
        settings.setTextColor(Color.WHITE);
        settings.setBackground(round(0xAA1B1B1B, 14));
        settings.setVisibility(View.GONE);
        settings.setOnClickListener(v -> Toast.makeText(this, "Settings", Toast.LENGTH_SHORT).show());
        top.addView(settings, new LinearLayout.LayoutParams(dp(48), dp(44)));
        top.addView(online);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        tlp.setMargins(0, dp(16), dp(16), 0);
        root.addView(top, tlp);

        // bottom-left: social buttons
        LinearLayout soc = new LinearLayout(this);
        soc.setPadding(dp(8), dp(8), dp(8), dp(8));
        soc.setBackground(round(0xAA1B1B1B, 14));
        String[][] s = {{"Discord", DISCORD}, {"Instagram", INSTAGRAM}, {"Website", WEBSITE}, {"App", APP_LINK}};
        for (String[] x : s) {
            Button t = new Button(this);
            t.setText(x[0]); t.setTextColor(Color.WHITE); t.setAllCaps(false); t.setTextSize(12);
            t.setBackground(round(0x33FFFFFF, 10));
            t.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(x[1]))));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(40));
            p.setMargins(dp(4), 0, dp(4), 0);
            soc.addView(t, p);
        }
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        slp.setMargins(dp(16), 0, 0, dp(16));
        root.addView(soc, slp);

        // bottom-right: players card (hidden until game is ready), progress, button
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        playersCard = new LinearLayout(this);
        playersCard.setOrientation(LinearLayout.VERTICAL);
        playersCard.setPadding(dp(16), dp(12), dp(16), dp(12));
        playersCard.setBackground(round(0xAA1B1B1B, 14));
        players = new TextView(this);
        players.setTextColor(Color.WHITE); players.setTextSize(20);
        playersCard.addView(players);
        playersCard.setVisibility(View.GONE);
        right.addView(playersCard, new LinearLayout.LayoutParams(-1, -2));
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100); bar.setVisibility(View.GONE);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(8));
        bp.setMargins(0, dp(10), 0, dp(6));
        right.addView(bar, bp);
        action = new Button(this);
        action.setTextColor(Color.WHITE); action.setTextSize(20);
        action.setTypeface(null, android.graphics.Typeface.BOLD);
        action.setBackground(round(0xFFF28C00, 18));
        action.setOnClickListener(v -> onAction());
        right.addView(action, new LinearLayout.LayoutParams(-1, dp(56)));
        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(dp(300), -2, Gravity.BOTTOM | Gravity.END);
        rlp.setMargins(0, 0, dp(16), dp(16));
        root.addView(right, rlp);

        setContentView(root);
        refreshState();
    }

    boolean installed() { return sp.getBoolean("installed", false); }

    void refreshState() {
        if (installed()) {
            action.setText("BILOW");
            settings.setVisibility(View.VISIBLE);
            playersCard.setVisibility(View.VISIBLE);
            online.setVisibility(View.VISIBLE);
            players.setText("...");
            queryPlayers();
            startMusic();
        } else {
            action.setText("CUSBOONAYSI");
            settings.setVisibility(View.GONE);
            playersCard.setVisibility(View.GONE);
            online.setVisibility(View.GONE);
        }
    }

    void onAction() {
        sp.edit().putString("name", name.getText().toString().trim()).apply();
        if (installed()) { play(); } else { update(); }
    }

    void play() {
        stopMusic();
        if (GAME_ID.isEmpty()) { toast("Game ID ma jiro"); return; }
        Intent i = getPackageManager().getLaunchIntentForPackage(GAME_ID);
        if (i == null) { toast("Ciyaarta lama helin"); return; }
        startActivity(i);
    }

    void update() {
        if (GAME_URL.isEmpty()) { toast("Link-ga ciyaarta ma jiro"); return; }
        action.setEnabled(false); bar.setVisibility(View.VISIBLE);
        new Thread(() -> {
            try {
                File dir = new File(getExternalFilesDir(null), "game");
                dir.mkdirs();
                File zip = new File(getCacheDir(), "game.zip");
                HttpURLConnection c = (HttpURLConnection) new URL(GAME_URL).openConnection();
                int len = c.getContentLength();
                try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(zip)) {
                    byte[] buf = new byte[65536]; int n; long tot = 0;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n); tot += n;
                        if (len > 0) { final int pr = (int) (tot * 90 / len); runOnUiThread(() -> bar.setProgress(pr)); }
                    }
                }
                try (ZipInputStream z = new ZipInputStream(new FileInputStream(zip))) {
                    ZipEntry e;
                    while ((e = z.getNextEntry()) != null) {
                        File f = new File(dir, e.getName());
                        if (!f.getCanonicalPath().startsWith(dir.getCanonicalPath())) continue;
                        if (e.isDirectory()) { f.mkdirs(); continue; }
                        f.getParentFile().mkdirs();
                        try (OutputStream o = new FileOutputStream(f)) {
                            byte[] buf = new byte[65536]; int n;
                            while ((n = z.read(buf)) > 0) o.write(buf, 0, n);
                        }
                    }
                }
                zip.delete();
                sp.edit().putBoolean("installed", true).apply();
                runOnUiThread(() -> { bar.setVisibility(View.GONE); action.setEnabled(true); refreshState(); });
            } catch (Exception ex) {
                runOnUiThread(() -> { bar.setVisibility(View.GONE); action.setEnabled(true); toast("Khalad: " + ex.getMessage()); });
            }
        }).start();
    }

    // SA-MP server query: shows players / max
    void queryPlayers() {
        new Thread(() -> {
            String txt = "-";
            try (DatagramSocket s = new DatagramSocket()) {
                s.setSoTimeout(2500);
                String[] ip = SERVER_IP.split("\\.");
                byte[] q = new byte[11];
                q[0] = 'S'; q[1] = 'A'; q[2] = 'M'; q[3] = 'P';
                for (int i = 0; i < 4; i++) q[4 + i] = (byte) Integer.parseInt(ip[i]);
                q[8] = (byte) (SERVER_PORT & 0xFF); q[9] = (byte) ((SERVER_PORT >> 8) & 0xFF); q[10] = 'i';
                s.send(new DatagramPacket(q, q.length, InetAddress.getByName(SERVER_IP), SERVER_PORT));
                byte[] r = new byte[512];
                DatagramPacket p = new DatagramPacket(r, r.length);
                s.receive(p);
                int pl = (r[12] & 0xFF) | ((r[13] & 0xFF) << 8);
                int mx = (r[14] & 0xFF) | ((r[15] & 0xFF) << 8);
                txt = pl + "/" + mx;
            } catch (Exception ignored) { }
            final String t = txt;
            runOnUiThread(() -> { players.setText(t); online.setText(t + "  ONLINE"); });
        }).start();
    }

    void startMusic() {
        if (mp != null) return;
        mp = MediaPlayer.create(this, R.raw.music);
        if (mp != null) { mp.setLooping(true); mp.start(); }
    }

    void stopMusic() {
        if (mp != null) { try { mp.stop(); mp.release(); } catch (Exception ignored) { } mp = null; }
    }

    @Override protected void onPause() { super.onPause(); stopMusic(); }
    @Override protected void onResume() { super.onResume(); if (installed()) startMusic(); }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); }
}
